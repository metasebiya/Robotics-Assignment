
"use strict";

let q1_msg = require('./q1_msg.js');

module.exports = {
  q1_msg: q1_msg,
};
