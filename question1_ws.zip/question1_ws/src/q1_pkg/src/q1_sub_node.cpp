#include <ros/ros.h>
#include "q1_pkg/q1_msg.h"
#include <vector>
#include <iostream>
#include <sstream>
void messageCallback(const q1_pkg::q1_msg::ConstPtr& msg) {
  ROS_INFO("I have received: [%f] [%f] [%f]", msg->linear.x, msg->linear.y, msg->linear.z);
}
 
int main(int argc, char **argv) {
  ros::init(argc, argv, "simple_subscriber_node_custom_msgs");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("q1_topic", 1000, messageCallback);
  ros::spin();
  return 0;
}