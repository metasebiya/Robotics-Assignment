#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include "q1_pkg/q1_msg.h"
#include <vector>
#include <iostream>
#include <sstream>
using namespace std;
int main(int argc, char **argv)
{
  float a,b,c;
  ros::init(argc, argv, "q1_publisher");
  ros::NodeHandle n;
  ros::Publisher pub = n.advertise<q1_pkg::q1_msg>("q1_topic", 1000);
  ros::Rate loop_rate(10);
  //cout << "Type a x value: "; 
    //cin >> a; 
   // cout << "Type a y value: "; 
   // cin >> b; 
   // cout << "Type a z value: "; 
    //cin >> c; 
    while (ros::ok()) {
      q1_pkg::q1_msg msg;
      msg.linear.x= 1.0;
      msg.linear.y= 2.0;
      msg.linear.z= 3.0;
      
      pub.publish(msg);
      ros::spinOnce();
      loop_rate.sleep();
    }
  return 0;
}